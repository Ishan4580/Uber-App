package com.rideshare.ride_service.Event;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Event published to Kafka when a ride is requested
 * Matching service consumes the event
 * TOPIC: ride.requested
 */

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RideRequestEvent {

    private String rideId;
    private String riderId;

    //PICKUP
    private double pickupLatitude;
    private double pickupLongitude;
    private String pickupAddress;

    //DROP
    private double dropLatitude;
    private double dropLongitude;
    private String dropAddress;
}
